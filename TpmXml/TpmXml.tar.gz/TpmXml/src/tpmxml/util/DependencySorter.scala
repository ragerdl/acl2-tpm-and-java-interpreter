package tpmxml.util

import tpmxml.data.TpmStructure
import tpmxml.data.TpmCommand

object DependencySorter {

    /**
     * Sorts structures in a def-before-use fashion. It accomplishes this task by creating
     * a dependency graph of the structures.
     * 
     * Of the four kinds of structure (redefinitions, flags, enumerations, and records),
     * redefinitions and records will have dependencies associated with them. Redefinitions
     * will have one dependency (the type they redefine) and records will have multiple 
     * dependencies (the types of their fields).
     * 
     * Once a dependency graph has been created (a graph is defined by a set of vertices
     * and a set of edges), a stratified topological sort is done, and each stratum is then
     * sorted by section and name.
     */
    def sortStructures(ss: List[TpmStructure]): Array[List[TpmStructure]] = {

        // ======================================================
        // Helper constants
        // ======================================================

        val sMap: Map[String, TpmStructure] = ss.map(s => (s.name, s)).toMap

        // ======================================================
        // Helper definitions
        // ======================================================

        // Get the dependency graph edges from this structure
        def edgeSet(s: TpmStructure): Set[(String, String)] = {
            def isPrimitive(s: String) = s.startsWith("BOOL") || s.startsWith("UINT") || s.startsWith("BYTE")
            def arrAdjust(s: String): String = if (s.endsWith("[]")) s.dropRight(2) else s

            if (s.fields.nonEmpty) {
                s.fields.filter { f => !isPrimitive(f.typeName) } map { f => (s.name, arrAdjust(f.typeName)) } toSet
            } else {
                if (s.values.isEmpty && !isPrimitive(s.typedef))
                    Set((s.name, arrAdjust(s.typedef)))
                else
                    Set.empty
            }
        }

        // Because these are lists of names, they must be converted to structures before sorting
        // As structures are the elements ultimately needed, this method returns a list of structures
        def sortBySecName(xs: List[String]): List[TpmStructure] = {
            val structs = xs.map(str => sMap(str))
            structs.sortBy(s => (s.chapter, s.majorSection, s.name))
        }

        def warning(name: String, undef: String) = "Warning: " + name + " depends on undefined type: " + undef

        // ======================================================
        // Method body
        // ======================================================

        // Get the set of vertices (nodes) and edges in the dependency graph, and create the graph
        // Only use names (Strings) instead of the entire structure, so that nodes have a natural ordering
        val nodes: Set[String] = ss.map(_.name).toSet
        val edges: Set[(String, String)] = ss.map(s => edgeSet(s)).flatten.toSet // set of edges in dependency graph
        edges.foreach { edge => if (!nodes.contains(edge._2)) println(warning(edge._1, edge._2)) } //DEBUG, but keep this in
        val depGraph = Digraph(nodes, edges) // Create the graph

        // Do a stratified topological sort of the graph, then sort strata by section and name, resulting in a list of structures
        val strata: Seq[Set[String]] = depGraph.stratifiedTopoSort
        val sortedStrata: Seq[List[TpmStructure]] = strata.map(ns => sortBySecName(ns.toList))

        //DEBUG
        var numOutStructs = sortedStrata.foldLeft(0) { (acc, lst) => acc + lst.length }
        println("Number of output structures: " + numOutStructs)

        return sortedStrata.reverse.toArray
    }
}