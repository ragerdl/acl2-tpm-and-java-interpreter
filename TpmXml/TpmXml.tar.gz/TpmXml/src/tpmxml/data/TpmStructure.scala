package tpmxml.data

case class TpmStructure(
    val section: String = "",
    val name: String,
    val typedef: String = "",
    val description: String = "",
    val restrictions: String = "", 	         // "none", "internal", "external"
    val comments: String = "",
    val valuesKind: String = "",		     // "none" (values.isEmpty), "numeric", "bit"
    val values: List[TpmValue] = List.empty, // if nonEmpty, then fields.isEmpty and typedef != "struct"
    val fields: List[TpmField] = List.empty  // if nonEmpty, then values.isEmpty and typedef = "struct"
    ) {

    import TpmStructure.Kind
    val kind: Kind.Value = {
        if (fields.nonEmpty && values.nonEmpty) Kind.Error
        else if (fields.nonEmpty) Kind.Record
        else if (values.nonEmpty) valuesKind match {
            case "bit" => Kind.Flag
            case "" | "numeric" => Kind.Enum
            case _ => Kind.Error
        }
        else typedef match {
            case "" => Kind.Error
            case _ => Kind.Rename
        }
    }
    
    override def toString = name + " (" + section + ")"
    
    val ChapterSection = """(\d+)\.(\d+)""".r

    val (chapter, majorSection) = section match {
        case ChapterSection(ch, sc) => (ch.toInt, sc.toInt)
        case _ => (0, 0)
    }

    def toXML =
        <structure>
            <name>{ name }</name>
            <section>{ section }</section>
            <typedef>{ typedef }</typedef>
            <description>{ description }</description>
            <restrictions>{ restrictions }</restrictions>
            <comments>{ comments }</comments>
            {
                if (values.isEmpty) xml.NodeSeq.Empty
                else <values>{ values.map(v => v.toXML).toSeq }</values> % xml.Attribute("kind", xml.Text(valuesKind), xml.Null)
            }
            {
                if (fields.isEmpty) xml.NodeSeq.Empty
                else <parameters>{ fields.map(f => f.toXML).toSeq }</parameters>
            }
        </structure>
}

object TpmStructure {

    object Kind extends Enumeration {
        val Record = Value
        val Enum = Value
        val Flag = Value
        val Rename = Value
        val Error = Value
    }
        
    def fromXML(node: scala.xml.Node): TpmStructure = {
        val valuesNode = (node \ "values")
        val fieldsNode = (node \ "parameters")
        TpmStructure(
            name = (node \ "name").text,
            section = (node \ "section").text,
            typedef = (node \ "typedef").text,
            description = (node \ "description").text,
            restrictions = (node \ "restrictions").text,
            comments = (node \ "comments").text,
            valuesKind = (valuesNode \ "@kind").text,
            values = (valuesNode \ "value").map(v => TpmValue.fromXML(v)).toList,
            fields = (fieldsNode \ "parameter").map(f => TpmField.fromXML(f)).toList)
    }
}