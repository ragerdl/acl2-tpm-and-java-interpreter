package tpmxml.apps

import tpmxml.data.{ TpmStructure, TpmField }

object StructurePrettyPrinter {

    // ==========================================================
    // Structure to print
    // ==========================================================

    val myStructName = "TPM_PERMANENT_DATA"

    // ==========================================================
    // Input
    // ==========================================================

    val TPMStructuresXMLFile = "resources/tpm-structures-2.xml"
    val tpmStructuresXml = xml.XML.loadFile(TPMStructuresXMLFile)
    val structures: List[TpmStructure] = (tpmStructuresXml \ "structure").map(TpmStructure.fromXML(_)).toList

    // ==========================================================
    // Structure Map
    // ==========================================================

    val sMap: Map[String, TpmStructure] = structures.map(s => (s.name, s)).toMap

    // ==========================================================
    // Definitions
    // ==========================================================

    def tab(n: Int) = "    " * n
    def tab: String = tab(1)

    // ==========================================================
    // Main method
    // ==========================================================    

    def main(args: Array[String]) {

        def primitive(s: String) = 
            s.startsWith("UINT") ||
            s.startsWith("BYTE") ||
            s.startsWith("BOOL") ||
            s.endsWith("[]")
        
        def printFields(fs: List[TpmField], indent: Int): Unit = {
            fs.foreach { f =>
                println(tab(indent) + f.name + ": " + f.typeName)
                if (!primitive(f.typeName)) {
                    val s = sMap(f.typeName)
                    if (s.fields.nonEmpty)
                        printFields(s.fields, indent + 1)
                }
            }
        }

        println(myStructName)

        val myStruct = sMap(myStructName)

        if (myStruct.fields.nonEmpty) printFields(myStruct.fields, 1)
    }
}