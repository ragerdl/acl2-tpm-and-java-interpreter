package tpmxml.apps

import tpmxml.data.TpmStructure

object CombineStructures {

    // ======================================================
    // Files
    // ====================================================== 

    val structuresFile = "resources/tpm-structures-2.xml"
    val addFile = "resources/tpm-structures-add.xml"
    val newStructuresFile = "resources/tpm-structures-3.xml"

    // ======================================================
    // Helper definitions
    // ====================================================== 

    private def sectionMax(s1: TpmStructure, s2: TpmStructure): String = {
        if (s1.chapter < s2.chapter) return s2.section
        if (s2.chapter < s1.chapter) return s1.section
        if (s1.majorSection <= s2.majorSection) s2.section else s1.section
    }

    private def mergeStructures(orig: TpmStructure, add: TpmStructure): TpmStructure = {
        val newDesc = if (orig.description == "") add.description else orig.description
        val newSec = sectionMax(orig, add)
        val newRedef = if (orig.typedef == "") add.typedef else orig.typedef
        orig.copy(section = newSec, typedef = newRedef, description = newDesc)
    }

    // Merges two lists of structures. Similar to merge in mergesort, but it merges the structures when they are equal
    // Because the original structures take precedence of the additional structure, the order of the incoming parameters
    // is important. Likewise the order is important in the internal recursive calls to mergeLists.
    // This only works for lists of < 10K elements
    // requires: the incoming lists must be sorted by structure name
    private def mergeLists(orig: List[TpmStructure], add: List[TpmStructure]): List[TpmStructure] =
        orig match {
            case Nil => add
            case _ => add match {
                case Nil => orig
                case addHead :: addTail =>
                    if (addHead.name == orig.head.name) mergeStructures(orig.head, addHead) :: mergeLists(orig.tail, addTail)
                    else if (addHead.name < orig.head.name) addHead :: mergeLists(orig, addTail)
                    else orig.head :: mergeLists(orig.tail, add)
            }
        }

    // Pretty prints an XML file
    // From gerferra in response to Stack Overflow question
    // @see http://stackoverflow.com/questions/3364627/how-to-produce-nicely-formatted-xml-in-scala
    private val Encoding = "UTF-8"
    private def save(node: scala.xml.Node, fileName: String) = {

        val pp = new scala.xml.PrettyPrinter(80, 4)
        val fos = new java.io.FileOutputStream(fileName)
        val writer = java.nio.channels.Channels.newWriter(fos.getChannel(), Encoding)

        try {
            writer.write("<?xml version='1.0' encoding='" + Encoding + "'?>\n")
            writer.write(pp.format(node))
        } finally {
            writer.close()
        }

        fileName
    }

    // ======================================================
    // Main method
    // ====================================================== 

    def main(args: Array[String]) {

        // Read in files and convert to list of TPM structures
        val structuresOrig = xml.XML.loadFile(structuresFile)
        val structuresAdd = xml.XML.loadFile(addFile)
        val origStructures: List[TpmStructure] = (structuresOrig \ "structure").map(TpmStructure.fromXML(_)).toList
        val addStructures: List[TpmStructure] = (structuresAdd \ "structure").map(TpmStructure.fromXML(_)).toList

        // Sort lists by name, merge them, then sort result by chapter, section, and name
        val sortedOrig = origStructures.sortBy(_.name)
        val sortedAdd = addStructures.sortBy(_.name)
        val newStructures = mergeLists(sortedOrig, sortedAdd)
        val sortedNew = newStructures.sortBy(s => (s.chapter, s.majorSection, s.name))

        // Translate to XML and wrap in a node, which can be output in a file
        val nodeSeq = sortedNew.map(s => s.toXML).toSeq
        val node = <structures> { nodeSeq } </structures>

        // Output the XML file in pretty printed format
        save(node, newStructuresFile)
    }
}