package tpmxml.apps

import tpmxml.data._
import collection._

object HtmlTable3 {

    def main(args: Array[String]) {

        // ======================================================
        // Files
        // ====================================================== 

        val TPMStructuresXMLFile = "resources/tpm-structures-3.xml"
        val TPMCommandsXMLFile = "resources/tpm-commands-2.xml"
        val TPMStructuresHTMLFile = "resources/tpm-structures-3.html"

        // ======================================================
        // Load XML files / transfer data into objects / and map names to objects
        // ======================================================

        val tpmStructuresXml = xml.XML.loadFile(TPMStructuresXMLFile)
        val tpmCommandsXml = xml.XML.loadFile(TPMCommandsXMLFile)
        val structures: List[TpmStructure] = (tpmStructuresXml \ "structure").map(TpmStructure.fromXML(_)).toList
        val commands: List[TpmCommand] = (tpmCommandsXml \ "command").map(TpmCommand.fromXML(_)).toList
        // Map names to structure/command objects
        val sMap = structures.map(s => (s.name, s)).toMap
        val cMap = commands.map(c => (c.name, c)).toMap        
            
        // ======================================================
        // Constants
        // ======================================================

        val styleInfo = "<style type=\"text/css\">\n<!--\nbody,td,th {\n" +
            "\tfont-family: Verdana, Arial, Helvetica, sans-serif;\n" +
            "\tfont-size: small;\n}\n-->\n</style>\n"
        val pageHeader = "<html>\n<head>\n<title>TPM Structures and Commands</title>\n" +
            styleInfo + "</head>\n<body>\n"
        val pageFooter = "</body>\n</html>"
        // Note: tableHeader depends on input; see helper definitions below
        val tableFooter = "</table>\n"

        // ======================================================
        // Multimaps from names to sets of structure names
        // ======================================================

        val fieldOf = new mutable.HashMap[String, mutable.Set[String]] with mutable.MultiMap[String, String] // mutable
        val inParamOf = new mutable.HashMap[String, mutable.Set[String]] with mutable.MultiMap[String, String] // mutable
        val outParamOf = new mutable.HashMap[String, mutable.Set[String]] with mutable.MultiMap[String, String] // mutable

        // ======================================================
        // Helper definitions
        // ======================================================

        def tableHeader(title: String, labels: List[String]) = {
            val headerCells = labels.map(label => "<th scope=\"col\">" + label + "</th>")
            val headerRow = headerCells.mkString("\t<tr>\n\t\t", "\n\t\t", "\n\t</tr>\n")
            "<h1>" + title + "</h1>\n" + "<table border=\"1\">\n" + headerRow
        }

        def hyperlinkedStructureName(name: String): String = {
            if (sMap.contains(name)) {
                "<a href=\"#" + name + "\">" + name + "</a> (" + sMap(name).section + ")"
            } else {
                name
            }
        }

        def hyperlinkedCommandName(name: String): String = {
            if (cMap.contains(name)) {
                "<a href=\"#" + name + "\">" + name + "</a> (" + cMap(name).section + ")"
            } else {
                name
            }
        }

        // ======================================================
        // Definitions that restrict displayed parameters
        // ======================================================

        def inParamSlice(cName: String, params: List[TpmParameter]): List[TpmParameter] = {
            val paramsLength = params.length

            if (paramsLength < 3) {
                println("Error: " + cName + ": not enough in params")
                params
            } else {
                params.head.description match {
                    case "TPM_TAG_RQU_COMMAND" => params.drop(3)
                    case "TPM_TAG_RQU_AUTH1_COMMAND" =>
                        if (params.length < 8) {
                            println("Error: " + cName + ": not enough in params for auth1")
                            params
                        } else
                            params.drop(3).dropRight(5)
                    case "TPM_TAG_RQU_AUTH2_COMMAND" =>
                        if (params.length < 13) {
                            println("Error: " + cName + ": not enough in params for auth2")
                            params
                        } else
                            params.drop(3).dropRight(10)
                    case _ => {
                    	println("Error: " + cName + ": in-tag description not recognized")
                        params
                    }
                }
            }
        }

        def outParamSlice(cName: String, params: List[TpmParameter]): List[TpmParameter] = {
            val paramsLength = params.length

            if (paramsLength < 4) {
                println("Error: " + cName + ": not enough in params")
                params
            } else {
                params.head.description match {
                    case "TPM_TAG_RSP_COMMAND" => params.drop(4)
                    case "TPM_TAG_RSP_AUTH1_COMMAND" =>
                        if (params.length < 8) {
                            println("Error: " + cName + ": not enough out params for auth1")
                            params
                        } else
                            params.drop(4).dropRight(4)
                    case "TPM_TAG_RSP_AUTH2_COMMAND" =>
                        if (params.length < 12) {
                            println("Error: " + cName + ": not enough out params for auth2")
                            params                            
                        } else
                            params.drop(4).dropRight(8)
                    case _ => {
                    	println("Error: " + cName + ": out-tag description not recognized")
                        params                        
                    } 
                }
            }
        }

        // ======================================================
        // Definitions that create table rows
        // ======================================================

        //TODO Add size in parens next to UINT32 parameters with "Size" at the end of their names
        def getStructureTableRow(s: TpmStructure): String = {
            val result = "\t<tr valign=\"top\">\n" +
                "\t\t<td>" + s.section + "</td>\n" +
                "\t\t<td><a name=\"" + s.name + "\" id=\"" + s.name + "\">" + // HTML anchor
                "</a>" + s.name + "</td>\n" +
                "\t\t<td>" + fieldList(s.fields) + "</td>\n" +
                "\t\t<td>" + (if (fieldOf.contains(s.name)) sortedCrossRefStructList(fieldOf(s.name)) else "") + "</td>\n" +
                "\t\t<td>" + (if (inParamOf.contains(s.name)) sortedCrossRefCommList(inParamOf(s.name)) else "") + "</td>\n" +
                "\t\t<td>" + (if (outParamOf.contains(s.name)) sortedCrossRefCommList(outParamOf(s.name)) else "") + "</td>\n" +
                "\t</tr>\n"
            return result
        }

        //TODO Add typedef in parens next to the name
        def getValueTableRow(s: TpmStructure): String = {
            val result = "\t<tr valign=\"top\">\n" +
                "\t\t<td>" + s.section + "</td>\n" +
                "\t\t<td><a name=\"" + s.name + "\" id=\"" + s.name + "\">" + // HTML anchor
                "</a>" + s.name + " (" + s.typedef + ")</td>\n" +
                "\t\t<td>" + (if (s.values.isEmpty) " " else crossRefList(s.values.map(_.name))) + "</td>\n" +
                "\t\t<td>" + (if (fieldOf.contains(s.name)) sortedCrossRefStructList(fieldOf(s.name)) else "") + "</td>\n" +
                "\t\t<td>" + (if (inParamOf.contains(s.name)) sortedCrossRefCommList(inParamOf(s.name)) else "") + "</td>\n" +
                "\t\t<td>" + (if (outParamOf.contains(s.name)) sortedCrossRefCommList(outParamOf(s.name)) else "") + "</td>\n" +
                "\t</tr>\n"
            return result
        }

        //TODO Add size in parens next to UINT32 parameters with "Size" at the end of their names
        def getCommandTableRow(c: TpmCommand): String = {
            val inSlice = inParamSlice(c.name, c.inParams)
            val outSlice = outParamSlice(c.name, c.outParams)
            val result = "\t<tr valign=\"top\">\n" +
                "\t\t<td>" + c.section + "</td>\n" +
                "\t\t<td><a name=\"" + c.name + "\" id=\"" + c.name + "\">" + // HTML anchor
                "</a>" + c.name + "</td>\n" +
                "\t\t<td><div align=\"center\">" + authDataNum(c) + "</div></td>\n" +
                "\t\t<td>" + (if (inSlice.nonEmpty) paramList(inSlice) else "") + "</td>\n" +
                "\t\t<td>" + (if (outSlice.nonEmpty) paramList(outSlice) else "") + "</td>\n" +
                "\t</tr>\n"
            return result
        }

        def authDataNum(c: TpmCommand): String = {
            val params = c.inParams
            val paramsLength = params.length

            if (params.isEmpty) {
                "No params"
            } else {
                params.head.description match {
                    case "TPM_TAG_RQU_COMMAND" => "0"
                    case "TPM_TAG_RQU_AUTH1_COMMAND" => "1"
                    case "TPM_TAG_RQU_AUTH2_COMMAND" => "2"
                    case _ => "Error"
                }
            }
        }

        def paramList(ps: List[TpmParameter]): String = {
            crossRefList2(ps.map { p => (p.name, p.typeName) })
        }
        
        def fieldList(fs: List[TpmField]): String = {
            crossRefList2(fs.map { f => (f.name, f.typeName) })
        }
        
        def crossRefList(s: List[String]): String = {
            val hyperlinkedList = s.map(hyperlinkedStructureName(_))
            hyperlinkedList.mkString("<ul>\n\t\t\t<li>", "</li>\n\t\t\t<li>", "</li>\n</ul>")
        }

        // requires: first string of each pair is name, second is type
        def crossRefList2(ps: List[(String, String)]): String = {
            def strEntry = ps.map { p => 
            	if (sMap.contains(p._2))
            		"<a href=\"#" + p._2 + "\">" + p._2 + "</a> (" + sMap(p._2).section + ")"
            	else if (p._2 == "UINT32" && p._1.endsWith("Size"))
            	    p._2 + " (size)"
            	else
            		p._2
            }
            strEntry.mkString("<ul>\n\t\t\t<li>", "</li>\n\t\t\t<li>", "</li>\n</ul>")
        }
        
        // sort this one by section, name
        def sortedCrossRefCommList(s: Set[String]): String = {
            val comms = s.toList.map(x => cMap(x))
            val sorted = comms.sortBy(c => (c.chapter, c.majorSection, c.name))
            val names = sorted.map(_.name)
            val list = names.map(hyperlinkedCommandName(_))
            list.mkString("<ul>\n\t\t\t<li>", "</li>\n\t\t\t<li>", "</li>\n</ul>")
        }

        def sortedCrossRefStructList(s: Set[String]): String = {
            val structs = s.toList.map(x => sMap(x))
            val sorted = structs.sortBy(s => (s.chapter, s.majorSection, s.name))
            val names = sorted.map(_.name)
            val list = names.map(hyperlinkedStructureName(_))
            names.mkString("<ul>\n\t\t\t<li>", "</li>\n\t\t\t<li>", "</li>\n</ul>")
        }
        
        // ======================================================
        // Populate maps
        // ======================================================

        /* Populate fieldOf, inParamOf, and outParamOf multi-maps */
        for (s <- structures; f <- s.fields) fieldOf.addBinding(f.typeName, s.name)
        for (c <- commands; p <- inParamSlice(c.name, c.inParams)) inParamOf.addBinding(p.typeName, c.name)
        for (c <- commands; p <- outParamSlice(c.name, c.outParams)) outParamOf.addBinding(p.typeName, c.name)

        // ======================================================
        // Create HTML
        // ======================================================        

        /* Create the structure table */
        val structureTableRows: List[String] = structures.filter(_.fields.nonEmpty).map(getStructureTableRow(_))
        val structureLabels = List("Sec", "Structure", "Fields", "Field of:", "In-Param of:", "Out-Param of:")
        val structureTable = tableHeader("Structures", structureLabels) + structureTableRows.mkString + tableFooter

        /* Create the value table */
        val valueTableRows: List[String] = structures.filter(_.fields.isEmpty).map(getValueTableRow(_))
        val valueLabels = List("Sec", "Structure", "Values", "Field of:", "In-Param of:", "Out-Param of:")
        val valueTable = tableHeader("Values", valueLabels) + valueTableRows.mkString + tableFooter

        /* Create the command table */
        val commandTableRows: List[String] = commands.map(getCommandTableRow(_))
        val commandLabels = List("Sec", "Command", "Auth Blocks", "In-Params", "Out-Params")
        val commandTable = tableHeader("Commands", commandLabels) + commandTableRows.mkString + tableFooter

        /* Write to HTML file */
        val out = new java.io.FileWriter(TPMStructuresHTMLFile)
        out.write(pageHeader + structureTable + valueTable + commandTable + pageFooter)
        out.close
    }
}