package tpmxml.apps

import tpmxml.data._
import tpmxml.util.CaseConverter._

/**
 * Creates Scala class files (*.scala) that contains all the structures from the TPM XML file.
 *
 *  The structures are broken down into four kinds:
 *
 *  (1) records -- those with fields
 *  (2) enums -- those with values
 *  (3) flags -- those with bit values
 *  (4) redefs -- those with neither fields nor values
 *
 *  In Scala, these structures take the following form:
 *
 * // Records
 * # C-type structure
 * typedef struct tdTPM_KEY12 {
 *     TPM_STRUCTURE_TAG tag;
 *     UINT16 fill;
 *     TPM_KEY_USAGE keyUsage;
 *     TPM_KEY_FLAGS keyFlags;
 *     TPM_AUTH_DATA_USAGE authDataUsage;
 *     TPM_KEY_PARMS algorithmParms;
 *     UINT32 PCRInfoSize;
 *     BYTE[] PCRInfo; // size is PCRInfoSize
 *     TPM_STORE_PUBKEY pubKey;
 *     UINT32 encDataSize;
 *     BYTE[] encData; // size is encDataSize
 * } TPM_KEY12;
 *
 * # Scala translation
 *
 * param fill description
 * param keyUsage description
 * ...
 * case class TpmKey12 (
 *      val fill: Integer = 0,
 *      val keyUsage: TpmKeyUsage.Value = TpmKeyUsage.Default,
 *      val keyFlags: Set[TpmKeyFlag.Value] = Set.empty,
 *      val authDataUsage: TpmAuthDataUsage.Value = TpmAuthDataUsage.Default,
 *      val algorithmParms: TpmKeyParms = TpmKeyParms(),
 *      val pcrInfo: Array[Byte] = null,
 *      val pubKey: TpmStorePubkey = TpmStorePubkey(),
 *      val encData: Array[Byte] = null)
 *
 * # Notes
 * - Structure tag is ignored
 * - All integers whose names end in 'Size' are ignored
 * - Enum types become {typename}.Value
 * - Flag types become Set[{typename}.Value] (The last 's' of the typename -- if present -- is omitted)
 *
 * // Enumerations
 * # TPM_KEY_USAGE is defined as UINT32 in section 2.2. It's values are given in section 5.8
 * - TPM_KEY_SIGNING
 * - TPM_KEY_STORAGE
 * - TPM_KEY_IDENTITY
 * - TPM_KEY_AUTHCHANGE
 * - TPM_KEY_BIND
 * - TPM_KEY_LEGACY
 * - TPM_KEY_MIGRATE
 *
 * # Scala translation
 * object TpmKeyUsage extends Enumeration {
 *     val Default = Value          // default value
 *     val TpmKeySigning = Value    // description
 *     val TpmKeyStorage = Value    // description
 *     val TpmKeyIdentity = Value   // description
 *     val TpmKeyAuthchange = Value // description
 *     val TpmKeyKeyBind = Value    // description
 *     val TpmKeyKeyLegacy = Value  // description
 *     val TpmKeyMigrate = Value    // description
 * }
 *
 * // Flags
 * # TPM_KEY_FLAGS is defined as UINT32 in section 2.2. It's (bit) values are given in section 5.10
 * - redirection
 * - migratable
 * - isVolatile
 * - pcrIgnoredOnRead
 * - migrateAuthority
 *
 * # Scala translation
 * object TpmKeyFlag extends Enumeration {
 *     val Redirection = Value
 *     val Migratable = Value
 *     val IsVolatile = Value
 *     val PcrIgnoredOnRead = Value
 *     val MigrateAuthority = Value
 * }
 *
 * # Notes
 * - The final 's' is dropped from the name
 * - When used in a class or method, TPM_KEY_FLAGS becomes Set[TpmKeyFlag.Value]
 *
 * // Redefinitions
 * BOOLs become Boolean, BYTEs become Byte, UINT##s become Integer
 * BYTE[] becomes Array[Byte]
 * BYTE[20] becomes Array[Byte] and the restriction will eventually become an assertion: assert(a.length == 20)
 * Other redefinitions are completely new types that have the same implementation as the type they redefine.
 * For example: TPM_AUTHDATA is defined as Array[Byte]. Since TPM_SECRET is a redefinition, it is also defined that way.
 */
object ScalaStructures {

    // ==========================================================
    // Constants and simple definitions
    // ==========================================================

    val tcgConstants = List(("TPMX_NUM_COUNTERS" -> 4), ("TPM_NUM_PCR" -> 16), ("TPMX_NUM_SESSION_LIST" -> 16), ("TPMX_NUM_SESSIONS" -> 3))
    val tcgInts = List("BYTE", "UINT16", "UINT32", "UINT64")
    val tcgIntArrays = List("BYTE", "UINT32")
    val tcgByteArrayLengths = List(4, 16, 20, 26, 128, 256)
    val tcgTpmArrays = List("TPM_PCRVALUE", "TPM_DIGEST", "TPM_COUNTER_VALUE", "TPM_SESSION_DATA", "TPM_KEY", "TPM_PCR_ATTRIBUTES", "TPM_DIRVALUE")

    val FixedByteArray = """BYTE\[(\d+)\]""".r
    val commentBar = "// =============================================================="
    val descMax = 200

    def header(s: String) = "\n" + commentBar + "\n// " + s + "\n" + commentBar + "\n\n"
    def padding(s: String, to: Int): String = " " * (to - s.length())

    // ==========================================================
    // Input File and output directory
    // ==========================================================

    val structuresInputFile = "resources/tpm-structures.xml" // input file
    val structuresDir = "resources/scala/tpm/structures/" // output directory

    // ==========================================================
    // Custom structures
    // ==========================================================

    val tpmxAuthInfoFields: List[TpmField] = List(
        TpmField("authHandle", "TPM_AUTHHANDLE"),
        TpmField("nonceEven", "TPM_NONCE"),
        TpmField("nonceOdd", "TPM_NONCE"),
        TpmField("continueAuthSession", "BOOL"),
        TpmField("authData", "TPM_AUTHDATA"))
    val tpmxAuthInfo = TpmStructure(name = "TPMX_AUTH_INFO", fields = tpmxAuthInfoFields)

    val tpmxInternalSaveDataFields: List[TpmField] = List(
        TpmField("pcr", "TPM_PCRVALUE[]", description = "Unresetable PCRs"),
        TpmField("auditDigest", "TPM_DIGEST", description = "Audit digest (optional)"),
        TpmField("stclearData", "TPM_STCLEAR_DATA", description = "Most of the data in this structure resets on TPM_Startup(ST_CLEAR)."),
        TpmField("stclearFlags", "TPM_STCLEAR_FLAGS", description = "These flags maintain state that is reset on each TPM_Startup(ST_CLEAR) command. The values are not affected by TPM_Startup(ST_STATE) commands."),
        TpmField("loadedKeys", "TPM_KEY[]", description = "Loaded key where parentPCRstatus == true (mandatory); other loaded keys (optional)"),
        TpmField("ownerEvictKeys", "TPM_KEY[]", description = "Any key where TPM_KEY_CONTROL_EVICT == true."),
        TpmField("sessions", "TPM_SESSION_DATA[]", description = "Any session (optional)"))
    val tpmxInternalSaveData = TpmStructure(name = "TPMX_INTERNAL_SAVE_DATA", fields = tpmxInternalSaveDataFields)

    val tpmxInternalDataFields: List[TpmField] = List(
        TpmField("permanentFlags", "TPM_PERMANENT_FLAGS", description = "These flags maintain state information for the TPM. The values are not affected by any TPM_Startup command."),
        TpmField("stclearFlags", "TPM_STCLEAR_FLAGS", description = "These flags maintain state that is reset on each TPM_Startup(ST_CLEAR) command. The values are not affected by TPM_Startup(ST_STATE) commands."),
        TpmField("stanyFlags", "TPM_STANY_FLAGS", description = "These flags reset on any TPM_Startup command."),
        TpmField("permanentData", "TPM_PERMANENT_DATA", description = "This structure contains the data fields that are permanently held in the TPM and not affected by TPM_Startup(any)."),
        TpmField("stclearData", "TPM_STCLEAR_DATA", description = "Most of the data in this structure resets on TPM_Startup(ST_CLEAR)."),
        TpmField("stanyData", "TPM_STANY_DATA", description = "Most of the data in this structure resets on TPM_Startup(ST_STATE)."))
    val tpmxInternalData = TpmStructure(name = "TPMX_INTERNAL_DATA", fields = tpmxInternalDataFields)

    // ==========================================================
    // Main method
    // ==========================================================    

    def main(args: Array[String]) {

        // ======================================================
        // Read structures from XML, create List[TpmStructure], create Map[String(name) -> TpmStructure]
        // ======================================================

        val tpmStructuresXml = xml.XML.loadFile(structuresInputFile)
        val structures: List[TpmStructure] = (tpmStructuresXml \ "structure").map(TpmStructure.fromXML(_)).toList
        val structuresMod = tpmxAuthInfo :: tpmxInternalSaveData :: tpmxInternalData :: structures
        val sMap: Map[String, TpmStructure] = structuresMod.map(s => (s.name, s)).toMap

        // ======================================================
        // Define directories
        // ======================================================

        val packages = Vector(
            "custom",
            "scope",
            "helper",
            "structtags",
            "types",
            "basic",
            "tpmtags",
            "internal",
            "pcr",
            "storage",
            "tpmkey",
            "signed",
            "identity",
            "transport",
            "audit",
            "tick",
            "return",
            "ordinals",
            "context",
            "nvstorage",
            "delegate",
            "capability",
            "daa",
            "redirection",
            "deprecated")

        // ======================================================
        // Helper definitions
        // ======================================================

        //        def createDir(s: String) = {
        //            val dir: java.io.File = new java.io.File(structuresOutputDir + s)
        //            val successful: Boolean = dir.mkdir()
        //            if (!successful) println("Could not create directory: " + dir.toString())
        //        }
        //
        //        packages.slice(2, packages.length).foreach(s => createDir(s))

        // ======================================================
        // Record creation method and associated definitions
        // ======================================================
            
        def scalaDesc(s: String): String = {
            val s1 = s.replace("\"", "'")
            if (s1.length > descMax) {
                s1.trim.take(descMax) + " ..."
            } else {
                s1.trim
            }
        }
            
        def getPackage(n: Int) = "package tpm.structures." + packages(n) + "\n\n"
        def caseClassSig(s: String) = "case class " + snakeToCamel(s).capitalize

        def isNeededField(f: TpmField): Boolean = {
            if (f.name.endsWith("Size") && f.typeName.startsWith("UINT")) false
            else if (f.typeName == "TPM_TAG_STRUCTURE") false
            else true
        }

        def getScalaDoc(fs: List[TpmField]): String = {
            def commentStr(f: TpmField) = " * @param " + f.name + " " + scalaDesc(f.description)
            val sb = new StringBuffer
            sb.append("/**\n")
            val fieldParams = fs.filter(f => isNeededField(f)).map(f => commentStr(f))
            if (fieldParams.nonEmpty) sb.append(fieldParams.mkString("\n") + "\n")
            sb.append(" */\n")
            sb.toString
        }

        def scalaFieldString(fs: List[TpmField]): String = {

            def scalaField(f: TpmField): String = {
                val scalaTypeAndDefault = f.typeName match {
                    case "BOOL" => "Boolean = false"
                    case "BYTE" => "Byte = 0"
                    case FixedByteArray(n) => "Array[Byte] = null"
                    case x if x.startsWith("UINT") => "Int = 0"
                    case x if x.endsWith("[]") => "Array[" + snakeToCamel(x.stripSuffix("[]")).capitalize + "] = null"
                    case x => {
                        if (sMap.contains(x)) {
                            val typeName = snakeToCamel(x).capitalize
                            sMap(x).kind match {
                                case TpmStructure.Kind.Record => typeName + " = " + typeName + "()"
                                case TpmStructure.Kind.Enum => typeName + ".Value = " + typeName + ".Default"
                                case TpmStructure.Kind.Flag => "Set[" + typeName + ".Value] = Set.empty"
                                case TpmStructure.Kind.Rename => typeName + " = " + typeName + "()"
                                case _ => throw new IllegalArgumentException()
                            }
                        } else throw new IllegalArgumentException(x + " is not a TPM type")
                    }
                }
                "val " + f.name + ": " + scalaTypeAndDefault
            }

            val lines = fs.filter(f => isNeededField(f)).map(f => scalaField(f))
            if (lines.isEmpty) "()"
            else if (lines.tail.isEmpty) "(" + lines.head + ")"
            else lines.mkString("(\n    ", ",\n    ", ")")
        }

        def scalaImportString(fs: List[TpmField]): String = {

            def needsImported(f: TpmField) = {
                f.typeName match {
                    case "BOOL" | "BYTE" | "BYTE[]" => false
                    case FixedByteArray(n) => false
                    case x if x.startsWith("UINT") => false
                    case _ => true
                }
            }

            def importLine(f: TpmField) = {
                val t = f.typeName
                val t2 = if (t.endsWith("[]")) t.stripSuffix("[]") else t
                if (sMap.contains(t2))
                    "import tpm.structures." + packages(sMap(t2).chapter) + "." + snakeToCamel(t2).capitalize + "\n"
                else throw new IllegalArgumentException(t2 + " is not a TPM type")
            }

            val lines = fs.filter(f => needsImported(f)).map(f => importLine(f))
            if (lines.isEmpty) "" else lines.distinct.sorted.mkString("") + "\n"
        }

        def scalaRecord(s: TpmStructure): String = {
            assert(s.kind == TpmStructure.Kind.Record)
            val sb = new StringBuffer
            sb.append(getPackage(s.chapter))
            sb.append(scalaImportString(s.fields))
            sb.append(getScalaDoc(s.fields))
            sb.append(caseClassSig(s.name))
            sb.append(scalaFieldString(s.fields) + "\n")
            sb.toString
        }

        def renamesPrimitive(s: TpmStructure) = {
            s.typedef match {
                case "BOOL" | "BYTE" | "BYTE[]" => true
                case FixedByteArray(n) => true
                case x if x.startsWith("UINT") => true
                case _ => false
            }
        }

        def renamesTpmType(s: TpmStructure) = (s.typedef.startsWith("TPM") && sMap.contains(s.typedef))

        def scalaWrapPrimitive(s: TpmStructure): String = {
            val sb = new StringBuffer
            sb.append(getPackage(s.chapter))
            sb.append(caseClassSig(s.name))
            sb.append(scalaFieldString(List(TpmField("x", s.typedef))) + "\n")
            sb.toString
        }

        def scalaRenameImpl(s: TpmStructure): String = {
            val sb = new StringBuffer
            sb.append(getPackage(s.chapter))
            sb.append(caseClassSig(s.name))
            sb.append(scalaFieldString(sMap(s.typedef).fields) + "\n")
            sb.toString
        }

        def scalaRename(s: TpmStructure): String = {
            assert(s.kind == TpmStructure.Kind.Rename)
            if (renamesPrimitive(s)) scalaWrapPrimitive(s)
            else if (renamesTpmType(s)) scalaRenameImpl(s)
            else throw new IllegalArgumentException(s.typedef + " is not a TPM type")
        }

        // ======================================================
        // Enumeration creation method and associated definitions
        // ======================================================

        def getScalaDoc2(vs: List[TpmValue]): String = {
            def commentStr(v: TpmValue) = " * @param " + snakeToCamel(v.name).capitalize + " " + scalaDesc(v.description)
            val sb = new StringBuffer
            sb.append("/**\n")
            val valueParams = vs.map(v => commentStr(v))
            if (valueParams.nonEmpty) sb.append(valueParams.mkString("\n") + "\n")
            sb.append(" */\n")
            sb.toString
        }
        
        def enumObjectSig(s: String) = "object " + snakeToCamel(s).capitalize + " extends Enumeration {\n"

        def scalaEnumValueString(vs: List[TpmValue]): String = {
            val maxLen = (7 :: vs.map(v => v.name.length)).max
            
            def scalaValue(v: TpmValue) = "val " + { if (v.name.contains('_')) snakeToCamel(v.name) else v.name } + " = Value"
            
            val vstr = vs.map(v => scalaValue(v)).mkString("    ", "\n    ", "\n")
            "    val Default = Value\n" + vstr
        }

        def scalaEnum(s: TpmStructure): String = {
            assert(s.kind == TpmStructure.Kind.Enum || s.kind == TpmStructure.Kind.Flag)
            val sb = new StringBuffer
            sb.append(getPackage(s.chapter))
            sb.append(getScalaDoc2(s.values))
            sb.append(enumObjectSig(s.name))
            sb.append(scalaEnumValueString(s.values))
            sb.append("}\n")
            sb.toString
        }

        // ======================================================
        // Iterate through structures and create files
        // ======================================================        

        // create the structures directory if it does not already exist
        val sDir = new java.io.File(structuresDir);
        if (!sDir.exists) {
            val succ = sDir.mkdirs
            if (!succ) println("Failed to create directory!")
        }
        
        // create package directories if they do not already exist
        for (p <- packages) {
            val dir = new java.io.File(structuresDir + p)
            if (!dir.exists) {
                val succ = dir.mkdir
                if (!succ) println("Failed to create directory!")
            }
        }
        
        for (s <- structuresMod) {
            val source = s.kind match {
                case TpmStructure.Kind.Enum | TpmStructure.Kind.Flag => scalaEnum(s)
                case TpmStructure.Kind.Record => scalaRecord(s)
                case TpmStructure.Kind.Rename => scalaRename(s)
                case _ => throw new IllegalArgumentException(s.name + " is not a valid structure")
            }
            val filename = structuresDir + packages(s.chapter) + "/" + snakeToCamel(s.name).capitalize + ".scala"
            printClassToFile(filename, source)
            //println(filename) //DEBUG
            //println(source) //DEBUG
        }

        def printClassToFile(filename: String, source: String) {
            val out = new java.io.FileWriter(filename)
            out.write(source)
            out.close
        }
    }
}
