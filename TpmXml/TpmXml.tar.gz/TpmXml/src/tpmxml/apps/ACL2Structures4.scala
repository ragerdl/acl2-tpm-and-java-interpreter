package tpmxml.apps

import tpmxml.data._
import tpmxml.util.CaseConverter._

/**
 * Creates an ACL2 file (*.lisp) that contains all the structures from the TPM XML file.
 *
 *  The structures are broken down into four kinds:
 *
 *  (1) records -- those with fields
 *  (2) enums -- those with values
 *  (3) flags -- those with bit values
 *  (4) redefs -- those with neither fields nor values
 *
 * Representative examples of each follow:
 * 
 * # Records ------------------------------------------------------------------------------
 * 
 * ## TCG Specification
 * 
 * typedef struct tdTPM_KEY12 {
 *    TPM_STRUCTURE_TAG tag;
 *    UINT16 fill;
 *    TPM_KEY_USAGE keyUsage;
 *    TPM_KEY_FLAGS keyFlags;
 *    TPM_AUTH_DATA_USAGE authDataUsage;
 *    TPM_KEY_PARMS algorithmParms;
 *    UINT32 PCRInfoSize;
 *    BYTE* PCRInfo;
 *    TPM_STORE_PUBKEY pubKey;
 *    UINT32 encDataSize;
 *    BYTE* encData;
 * } TPM_KEY12;
 * 
 * ## ACL2 Translation
 * 
 * ;; 10.3 TPM_KEY12()
 * (cutil::defaggregate tpm-key12
 *   ((tag tpm-structure-tag-p "MUST be TPM_TAG_KEY12"
 *      :default (make-tpm-structure-tag))
 *    (tpm-fill uint16-p "MUST be 0x0000"
 *      :default (make-uint16))
 *    (key-usage tpm-key-usage-p "This SHALL be the TPM key usage that determines the operations permitted with this key"
 *      :default (make-tpm-key-usage))
 *    (key-flags tpm-key-flags-p "This SHALL be the indication of migration, redirection etc."
 *      :default (make-tpm-key-flags))
 *    (auth-data-usage tpm-auth-data-usage-p "This SHALL Indicate the conditions where it is required that authorization be presented."
 *      :default (make-tpm-auth-data-usage))
 *    (algorithm-parms tpm-key-parms-p "This SHALL be the information regarding the algorithm for this key"
 *      :default (make-tpm-key-parms))
 *    (pcr-info-size uint32-p "This SHALL be the length of the pcrInfo parameter. If the key is not bound to a PCR this value SHOULD be 0."
 *      :default 0)
 *    (pcr-info byte-list-p "This SHALL be a structure of type TPM_PCR_INFO_LONG," :default (make-byte-list)
 *      :default nil)
 *    (pub-key tpm-store-pubkey-p "This SHALL be the public portion of the key"
 *      :default (make-tpm-store-pubkey))
 *    (enc-data-size uint32-p "This SHALL be the size of the encData parameter."
 *      :default 0)
 *    (enc-data byte-list-p "This SHALL be an encrypted TPM_STORE_ASYMKEY structure TPM_MIGRATE_ASYMKEY structure"
 *      :default nil)
 *   ))
 * 
 * # Enumerations -------------------------------------------------------------------------
 * 
 * ## TCG Specification
 * 
 * TPM_KEY_USAGE (defined as UINT32 in 2.2; values given in 5.8)
 * - TPM_KEY_SIGNING
 * - TPM_KEY_STORAGE
 * - TPM_KEY_IDENTITY
 * - TPM_KEY_AUTHCHANGE
 * - TPM_KEY_BIND
 * - TPM_KEY_LEGACY
 * - TPM_KEY_MIGRATE
 * 
 * ## ACL2 Translation
 * 
 * ;; 5.8 TPM_KEY_USAGE
 * ;; Indicates the permitted usage of the key.
 * (cutil::defenum tpm-key-usage-p
 *   (:tpmx-default-enum-value  
 *    :tpm-key-signing    ;; This SHALL indicate a signing key. The [private] key SHALL be used for signing operations, only. This means that it MUST be a leaf of the Protected Storage key hierarchy. ...
 *    :tpm-key-storage    ;; This SHALL indicate a storage key. The key SHALL be used to wrap and unwrap other keys in the Protected Storage hierarchy
 *    :tpm-key-identity   ;; This SHALL indicate an identity key. The key SHALL be used for operations that require a TPM identity, only.
 *    :tpm-key-authchange ;; This SHALL indicate an ephemeral key that is in use during the ChangeAuthAsym process, only.
 *    :tpm-key-bind       ;; This SHALL indicate a key that can be used for TPM_Bind and TPM_UnBind operations only.
 *    :tpm-key-legacy     ;; This SHALL indicate a key that can perform signing and binding operations. The key MAY be used for both signing and binding operations. The TPM_KEY_LEGACY key type is to allow for use by applications  ...
 *    :tpm-key-migrate    ;; This SHALL indicate a key in use for TPM_MigrateKey
 *   ))
 * 
 * (defnd make-tpm-key-usage ()
 *   :tpmx-default-enum-value)
 * 
 * # Flags --------------------------------------------------------------------------------
 * 
 * ## TCG Specification
 * 
 * TPM_KEY_FLAGS (defined as UINT32 in 2.2; bit values given in 5.10)
 * - redirection
 * - migratable
 * - isVolatile
 * - pcrIgnoredOnRead
 * - migrateAuthority
 * 
 * ## ACL2 Translation
 * 
 * ;; 5.10 TPM_KEY_FLAGS
 * ;; Indicates information regarding a key.
 * (cutil::defaggregate tpm-key-flags
 *   ((redirection booleanp :default nil)      ;; This mask value SHALL indicate the use of redirected output.
 *    (migratable booleanp :default nil)       ;; This mask value SHALL indicate that the key is migratable.
 *    (is-volatile booleanp :default nil)       ;; This mask value SHALL indicate that the key MUST be unloaded upon execution of the TPM_Startup(ST_Clear). This does not indicate that a nonvolatile key will remain loaded across TPM_Startup(ST_Clear)  ...
 *    (pcr-ignored-on-read booleanp :default nil) ;; When TRUE the TPM MUST NOT check digestAtRelease or localityAtRelease for commands that read the public portion of the key (e.g., TPM_GetPubKey) and MAY NOT check digestAtRelease or localityAtRelease  ...
 *    (migrate-authority booleanp :default nil) ;; When set indicates that the key is under control of a migration authority. The TPM MUST only allow the creation of a key with this flag in TPM_CMK_CreateKey
 *   ))
 * 
 * # Wrappers -----------------------------------------------------------------------------
 * 
 * ## TCG Specification
 * 
 * typedef BYTE tdTPM_AUTHDATA[20]
 * 
 * ## ACL2 Translation
 * 
 * ;; 5.6 TPM_AUTHDATA()
 * (defprimitive tpm-authdata-p (x)
 *   (20-byte-list-p x)
 *   :default (make-list 20 :initial-element (make-byte))
 * 
 * # Arrays -------------------------------------------------------------------------------
 * 
 * ## TCG Specification
 * 
 * TPM_DIGEST[]
 * 
 * ## ACL2 Translation
 * 
 * (cutil::deflist tpm-digest-list-p (x)
 *   (tpm-digest-p x)
 *   :elementp-of-nil nil
 *   :true-listp t
 *   :default nil)
 *   
 * # Primatives ---------------------------------------------------------------------------
 * 
 * ## TCG Specification
 * 
 * UINT32
 * UINT32[]
 * BYTE[4]
 * 
 * ## ACL2 Translation
 * 
 * (defprimitive uint32 (x)
 *   (and (integerp x)
 *        (<= 0 x)
 *        (<= x (- (expt 2 32) 1)))
 *   :default 0)
 *   
 * (cutil::deflist uint32-list-p (x)
 *   (uint32-p x)
 *   :elementp-of-nil nil
 *   :true-listp t
 *   :default nil)
 * 
 * (defprimitive 20-byte-list (lst)
 *   (and (byte-list-p lst)
 *        (equal (len lst) 20))
 *   :default (make-list 20 :initial-element 0))
 */
object ACL2Structures4 {

    // ==========================================================
    // Constants and simple definitions
    // ==========================================================

    val tcgConstants = List(("TPMX_NUM_COUNTERS" -> 4), ("TPM_NUM_PCR" -> 16), ("TPMX_NUM_SESSION_LIST" -> 16), ("TPMX_NUM_SESSIONS" -> 3))
    val tcgInts = List("BYTE", "UINT16", "UINT32", "UINT64")
    val tcgIntArrays = List("BYTE", "UINT32")
    val tcgByteArrayLengths = List(4, 16, 20, 26, 128, 256)
    val tcgTpmArrays = List("TPM_PCRVALUE", "TPM_DIGEST", "TPM_COUNTER_VALUE", "TPM_SESSION_DATA", "TPM_KEY", "TPM_PCR_ATTRIBUTES", "TPM_DIRVALUE")

    val FixedByteArray = """BYTE\[(\d+)\]""".r
    val commentBar = "; ==============================================================="
    val descMax = 200
    val parents = ":parents(tpm-structures)"

    def header(s: String) = "\n" + commentBar + "\n; " + s + "\n" + commentBar + "\n\n"
    def padding(s: String, to: Int): String = " " * (to - s.length())

    // ==========================================================
    // Input and Output File
    // ==========================================================

    val TPMStructuresXMLFile = "resources/tpm-structures.xml" // input
    val TCGStructuresACL2File = "resources/tpm-structures.lisp" // output

    // ==========================================================
    // Custom structures
    // ==========================================================

    val tpmxAuthInfoFields: List[TpmField] = List(
        TpmField("authHandle", "TPM_AUTHHANDLE"),
        TpmField("nonceEven", "TPM_NONCE"),
        TpmField("nonceOdd", "TPM_NONCE"),
        TpmField("continueAuthSession", "BOOL"),
        TpmField("authData", "TPM_AUTHDATA"))
    val tpmxAuthInfo = TpmStructure(name = "TPMX_AUTH_INFO", fields = tpmxAuthInfoFields)

    val tpmxInternalSaveDataFields: List[TpmField] = List(
        TpmField("pcr", "TPM_PCRVALUE[]", description = "Unresetable PCRs"),
        TpmField("auditDigest", "TPM_DIGEST", description = "Audit digest (optional)"),
        TpmField("stclearData", "TPM_STCLEAR_DATA", description = "Most of the data in this structure resets on TPM_Startup(ST_CLEAR)."),
        TpmField("stclearFlags", "TPM_STCLEAR_FLAGS", description = "These flags maintain state that is reset on each TPM_Startup(ST_CLEAR) command. The values are not affected by TPM_Startup(ST_STATE) commands."),
        TpmField("loadedKeys", "TPM_KEY[]", description = "Loaded key where parentPCRstatus == true (mandatory); other loaded keys (optional)"),
        TpmField("ownerEvictKeys", "TPM_KEY[]", description = "Any key where TPM_KEY_CONTROL_EVICT == true."),
        TpmField("sessions", "TPM_SESSION_DATA[]", description = "Any session (optional)"))
    val tpmxInternalSaveData = TpmStructure(name = "TPMX_INTERNAL_SAVE_DATA", fields = tpmxInternalSaveDataFields)

    val tpmxInternalDataFields: List[TpmField] = List(
        TpmField("permanentFlags", "TPM_PERMANENT_FLAGS", description = "These flags maintain state information for the TPM. The values are not affected by any TPM_Startup command."),
        TpmField("stclearFlags", "TPM_STCLEAR_FLAGS", description = "These flags maintain state that is reset on each TPM_Startup(ST_CLEAR) command. The values are not affected by TPM_Startup(ST_STATE) commands."),
        TpmField("stanyFlags", "TPM_STANY_FLAGS", description = "These flags reset on any TPM_Startup command."),
        TpmField("permanentData", "TPM_PERMANENT_DATA", description = "This structure contains the data fields that are permanently held in the TPM and not affected by TPM_Startup(any)."),
        TpmField("stclearData", "TPM_STCLEAR_DATA", description = "Most of the data in this structure resets on TPM_Startup(ST_CLEAR)."),
        TpmField("stanyData", "TPM_STANY_DATA", description = "Most of the data in this structure resets on TPM_Startup(ST_STATE)."),
        TpmField("saveData", "TPMX_INTERNAL_SAVE_DATA", description = "Data saved from TPM_SaveState command."),
        TpmField("keys", "TPM_KEY[]", description = "All TPM keys"),
        TpmField("loadedKeys", "TPM_KEY[]", description = "Loaded keys."))
    val tpmxInternalData = TpmStructure(name = "TPMX_INTERNAL_DATA", fields = tpmxInternalDataFields)

    // ==========================================================
    // Main method
    // ==========================================================    

    def main(args: Array[String]) {

        // ======================================================
        // Load file, add custom structures, and create maps
        // ======================================================

        val tpmStructuresXml = xml.XML.loadFile(TPMStructuresXMLFile)
        val structures: List[TpmStructure] = (tpmStructuresXml \ "structure").map(TpmStructure.fromXML(_)).toList

        val modStructures = tpmxInternalData :: tpmxInternalSaveData :: tpmxAuthInfo :: structures
        val sMap = structures.map(s => (s.name, s)).toMap

        // ======================================================
        // Check type names
        // ======================================================        

        def isTcgType(s: String) = s match {
            case "BOOL" | "BYTE" | "UINT16" | "UINT32" | "UINT64" => true
            case s if sMap.keySet.contains(s) => true
            case _ => false
        }

        def isTcgPrimative(s: String) = s match {
            case "BOOL" | "BYTE" | "UINT16" | "UINT32" | "UINT64" => true
            case _ => false
        }

        def isTcgCustomType(s: String) = s match {
            case s if sMap.keySet.contains(s) && s.startsWith("TPMX_") => true
            case _ => false
        }

        // ======================================================
        // Helper methods for creating ACL2 structures
        // ======================================================        

        def acl2Default(s: String): String = {
            s match {
                case x if x.endsWith("[]") => "(make-" + snakeToDash(x.stripSuffix("[]")) + "-list)" 
                case FixedByteArray(n) => "(make-" + n + "-byte-list)"
                case "BOOL" => "nil"
                case x if x == "BYTE" || x.startsWith("UINT") || x.startsWith("TPM_") || x.startsWith("TPMX_") => "(make-" + snakeToDash(s) + ")"
                case _ => throw new IllegalArgumentException(s + " is not a TCG type")
            }
        }

        def acl2Predicate(s: String): String = {
            s match {
                case x if x.endsWith("[]") => snakeToDash(x.stripSuffix("[]")) + "-list-p"
                case FixedByteArray(n) => n.toString + "-byte-list-p"
                case "BOOL" => "booleanp"
                case x if x == "BYTE" || x.startsWith("UINT") || x.startsWith("TPM_") || x.startsWith("TPMX_") => snakeToDash(x) + "-p"
                case _ => throw new IllegalArgumentException(s + " is not a TCG type")
            }
        }

        def acl2Desc(s: String): String = {
            val s1 = s.replace("\"", "'")
            if (s1.length > descMax) {
                s1.trim.take(descMax) + " ..."
            } else {
                s1.trim
            }
        }

        def acl2Symbol(s: String): String = s.toLowerCase match {
            case "reserved" | "unused" | "open" | "xx" => ";; " + s
            case _ => ":" + snakeToDash(s)
        }

        def intro(s: TpmStructure) = ";; " + s.section + " " + s.name +
            { if (s.description != "") "\n;; " + acl2Desc(s.description) } + "\n"

        def fieldnameToDash(s: String) = {
            if (s.contains("_")) snakeToDash(s)
            else if (s == "state") "tpm-state"
            else if (s == "fill") "tpm-fill"
            else camelToDash(s)
        }

        // ======================================================
        // Methods that create ACL2 structures
        // ======================================================        

        val UnsignedInt = """UINT(\d+)""".r

        def acl2Int(s: String) = {
            val max: String = s match {
                case "BYTE" => "255"
                case UnsignedInt(n) => "(- (expt 2 " + n + ") 1)"
                case _ => throw new IllegalArgumentException(s + " is not a TCG integer")
            }
            "(defprimitive " + snakeToDash(s) + " (x)\n" +
                "  (and (integerp x)\n" +
                "       (<= 0 x)\n" +
                "       (<= x " + max + "))\n" +
                "  :default 0\n  " + parents + ")\n"
        }
            
        def acl2List(s: String) = {
            assert(isTcgType(s), s + " is not a TCG type")
            "(cutil::deflist " + snakeToDash(s) + "-list-p (x)\n" +
                "  (" + snakeToDash(s) + "-p x)\n" +
                "  :elementp-of-nil nil\n" +
                "  :true-listp t\n  " + parents + ")\n\n" +
                "(defnd make-" + snakeToDash(s) + "-list ()\n  nil)\n"
        }

        def acl2FixedList(s: String, n: Int) = {
            assert(isTcgType(s), s + " is not a TCG type")
            "(defprimitive " + n + "-" + snakeToDash(s) + "-list (x)\n" +
                "  (and (" + snakeToDash(s) + "-list-p x)\n" +
                "       (equal (len x) " + n + "))\n" +
                "  :default (make-list " + n + " :initial-element " + acl2Default(s) + ")\n  " + parents + ")\n"
        }

        def acl2Rename(s: TpmStructure): String = {
            val str = intro(s) +
                "(defprimitive " + snakeToDash(s.name) + " (x)\n" +
                "  (" + acl2Predicate(s.typedef) + " x)\n" +
                "  :default " + acl2Default(s.typedef) + "\n  " + parents + ")\n"
            if (tcgTpmArrays.contains(s.name)) { str + "\n" + acl2List(s.name) }
            else str
        }

        def acl2Enum(s: TpmStructure): String = {
            val nameDescPairs: List[(String, String)] = s.values.map { v => (acl2Symbol(v.name), acl2Desc(v.description)) }
            val maxLen = nameDescPairs.map(p => p._1.length()).max
            val strs = nameDescPairs.map(p => p._1 + padding(p._1, maxLen) + " ;; " + p._2)
            val prefix = "  (:tpmx-default-enum-value\n   "
            val suffix = "\n  )\n  " + parents + ")\n\n(defnd make-" + snakeToDash(s.name) + " ()\n  :tpmx-default-enum-value)\n"
            val str = strs.mkString(prefix, "\n   ", suffix)
            intro(s) + "(cutil::defenum " + snakeToDash(s.name) + "-p\n" + str
        }

        def acl2Flag(s: TpmStructure): String = {
            val nameDescPairs: List[(String, String)] = s.values.map { v => (snakeToDash(v.name), acl2Desc(v.description)) }
            val maxLen = nameDescPairs.map(p => p._1.length()).max
            val strs = nameDescPairs.map(p => "(" + p._1 + " booleanp :default nil)" + padding(p._1, maxLen) + " ;; " + p._2)
            val str = strs.mkString("  (", "\n   ", "\n  )\n  " + parents + ")\n")
            intro(s) + "(cutil::defaggregate " + snakeToDash(s.name) + "\n" + str
        }

        def acl2Comment(s: String) = "\"" + acl2Desc(s.replace("\"", "'")) + "\""

        def acl2Record(s: TpmStructure): String = {
            val nameTypeDesc: List[String] = s.fields.map { f =>
                (fieldnameToDash(f.name) + " " +
                    acl2Predicate(f.typeName) + " " +
                    acl2Comment(f.description) + "\n     :default " +
                    acl2Default(f.typeName))
            }
            val strs = nameTypeDesc.map(s => "(" + s + ")")
            val str = strs.mkString("  (", "\n   ", "\n  )\n  " + parents + ")\n")
            val str2 = intro(s) + "(cutil::defaggregate " + snakeToDash(s.name) + "\n" + str
            if (tcgTpmArrays.contains(s.name)) { str2 + "\n" + acl2List(s.name) }
            else str2
        }

        // ======================================================
        // Build the header and the primitives
        // ======================================================        

        val acl2Header = "(in-package \"ACL2\")\n\n" +
            "(include-book \"cutil/deflist\" :dir :system)\n" +
            "(include-book \"cutil/defaggregate\" :dir :system)\n" +
            "(include-book \"cutil/defenum\" :dir :system)\n" +
            "(include-book \"defprimitive\")\n"

        val primHeader = header("primitive structures (integers and byte arrays)")
        val acl2IntStr = tcgInts.map(s => acl2Int(s)).mkString("\n") + "\n"      
        val acl2IntArrays = tcgIntArrays.map(s => acl2List(s)).mkString("\n") + "\n"
        val acl2FixedByteArrays = tcgByteArrayLengths.map(n => acl2FixedList("BYTE", n)).mkString("\n")

        val primitiveTypesString = acl2Header + primHeader + acl2IntStr + acl2IntArrays + acl2FixedByteArrays
        
        // ======================================================
        // Create StringBuffer, get strata, and combine everything
        // ======================================================        
        
        val sb = new StringBuffer

        val strataArray = tpmxml.util.DependencySorter.sortStructures(modStructures)

        sb.append(primitiveTypesString)

        for (i <- 0 to (strataArray.length - 1)) {
            val stratum = strataArray(i)

            val (recordStructures, nonRecordStructures) = stratum.partition(s => s.fields.nonEmpty)
            val (redefStructures, enumAndFlagStructures) = nonRecordStructures.partition(s => s.values.isEmpty)
            val (flagStructures, enumStructures) = enumAndFlagStructures.partition(s => s.valuesKind == "bit")

            val acl2Records = recordStructures.map(s => acl2Record(s)).mkString("\n")
            val acl2Enums = enumStructures.map(s => acl2Enum(s)).mkString("\n")
            val acl2Flags = flagStructures.map(s => acl2Flag(s)).mkString("\n")
            val acl2Redefs = redefStructures.map(s => acl2Rename(s)).mkString("\n")

            if (acl2Redefs != "") sb.append(header("Level " + i + " Wrappers") + acl2Redefs)
            if (acl2Flags != "") sb.append(header("Level " + i + " Flags") + acl2Flags)
            if (acl2Enums != "") sb.append(header("Level " + i + " Enumerations") + acl2Enums)
            if (acl2Records != "") sb.append(header("Level " + i + " Records") + acl2Records)
        }

        val out = new java.io.FileWriter(TCGStructuresACL2File)
        out.write(sb.toString)
        out.close
        
        // ======================================================
        // Create representative samples document
        // ======================================================
        
        val sb2 = new StringBuffer

        sb2.append("\n")
        sb2.append("# Records ------------------------------------------------------------------------------\n")
        sb2.append("\n")
        sb2.append("## TCG Specification\n")
        sb2.append("\n")
        sb2.append("typedef struct tdTPM_KEY12 {\n")
        sb2.append("   TPM_STRUCTURE_TAG tag;\n")
        sb2.append("   UINT16 fill;\n")
        sb2.append("   TPM_KEY_USAGE keyUsage;\n")
        sb2.append("   TPM_KEY_FLAGS keyFlags;\n")
        sb2.append("   TPM_AUTH_DATA_USAGE authDataUsage;\n")
        sb2.append("   TPM_KEY_PARMS algorithmParms;\n")
        sb2.append("   UINT32 PCRInfoSize;\n")
        sb2.append("   BYTE* PCRInfo;\n")
        sb2.append("   TPM_STORE_PUBKEY pubKey;\n")
        sb2.append("   UINT32 encDataSize;\n")
        sb2.append("   BYTE* encData;\n")
        sb2.append("} TPM_KEY12;\n")
        sb2.append("\n")
        sb2.append("## ACL2 Translation\n")
        sb2.append("\n")
        sb2.append(acl2Record(sMap("TPM_KEY12")) + "\n")
        sb2.append("\n")
        sb2.append("# Enumerations -------------------------------------------------------------------------\n")
        sb2.append("\n")
        sb2.append("## TCG Specification\n")
        sb2.append("\n")
        sb2.append("TPM_KEY_USAGE (defined as UINT32 in 2.2; values given in 5.8)\n")
        sb2.append("- TPM_KEY_SIGNING\n")
        sb2.append("- TPM_KEY_STORAGE\n")
        sb2.append("- TPM_KEY_IDENTITY\n")
        sb2.append("- TPM_KEY_AUTHCHANGE\n")
        sb2.append("- TPM_KEY_BIND\n")
        sb2.append("- TPM_KEY_LEGACY\n")
        sb2.append("- TPM_KEY_MIGRATE\n")
        sb2.append("\n")
        sb2.append("## ACL2 Translation\n")
        sb2.append("\n")
        sb2.append(acl2Enum(sMap("TPM_KEY_USAGE")) + "\n")
        sb2.append("\n")
        sb2.append("# Flags --------------------------------------------------------------------------------\n")
        sb2.append("\n")
        sb2.append("## TCG Specification\n")
        sb2.append("\n")
        sb2.append("TPM_KEY_FLAGS (defined as UINT32 in 2.2; bit values given in 5.10)\n")
        sb2.append("- redirection\n")
        sb2.append("- migratable\n")
        sb2.append("- isVolatile\n")
        sb2.append("- pcrIgnoredOnRead\n")
        sb2.append("- migrateAuthority\n")
        sb2.append("\n")
        sb2.append("## ACL2 Translation\n")
        sb2.append("\n")
        sb2.append(acl2Flag(sMap("TPM_KEY_FLAGS")) + "\n")
        sb2.append("\n")
        sb2.append("# Wrappers -----------------------------------------------------------------------------\n")
        sb2.append("\n")
        sb2.append("## TCG Specification\n")
        sb2.append("\n")
        sb2.append("typedef BYTE tdTPM_AUTHDATA[20]\n")
        sb2.append("\n")
        sb2.append("## ACL2 Translation\n")
        sb2.append("\n")
        sb2.append(acl2Rename(sMap("TPM_AUTHDATA")) + "\n")
        sb2.append("\n")
        sb2.append("# Arrays -------------------------------------------------------------------------------\n")
        sb2.append("\n")
        sb2.append("## TCG Specification\n")
        sb2.append("\n")
        sb2.append("TPM_DIGEST[]\n")
        sb2.append("\n")
        sb2.append("## ACL2 Translation\n")
        sb2.append("\n")
        sb2.append(acl2List("TPM_DIGEST") + "\n")
        sb2.append("  \n")
        sb2.append("# Primatives ---------------------------------------------------------------------------\n")
        sb2.append("\n")
        sb2.append("## TCG Specification\n")
        sb2.append("\n")
        sb2.append("UINT32\n")
        sb2.append("\n")
        sb2.append("UINT32[]\n")
        sb2.append("\n")
        sb2.append("BYTE[4]\n")
        sb2.append("\n")
        sb2.append("## ACL2 Translation\n")
        sb2.append("\n")
        sb2.append(acl2Int("UINT32") + "\n")
        sb2.append("  \n")
        sb2.append(acl2List("UINT32") + "\n")
        sb2.append("\n")
        sb2.append(acl2FixedList("BYTE", 4) + "\n")
        
        val TCG2ACL2SampleFile = "resources/tcg2acl2-sample.txt"
        val out2 = new java.io.FileWriter(TCG2ACL2SampleFile)
        out2.write(sb2.toString)
        out2.close
        
    }
}
