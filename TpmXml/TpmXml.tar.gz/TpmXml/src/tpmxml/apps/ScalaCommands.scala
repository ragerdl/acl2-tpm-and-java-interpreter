package tpmxml.apps

import tpmxml.data._
import tpmxml.util.CaseConverter._
import collection.mutable.ListBuffer

/**
 * # TCG TPM_MakeIdentity command:
 *
 * TPM_MakeIdentity
 *
 * TPM_TAG tag
 * UINT32 paramSize
 * TPM_COMMAND_CODE ordinal
 * TPM_ENCAUTH identityAuth
 * TPM_CHOSENID_HASH labelPrivCADigest
 * TPM_KEY idKeyParams
 * TPM_AUTHHANDLE srkAuthHandle
 * TPM_NONCE srkLastNonceEven
 * TPM_NONCE srknonceOdd
 * BOOL continueSrkSession
 * TPM_AUTHDATA srkAuth
 * TPM_AUTHHANDLE authHandle
 * TPM_NONCE authLastNonceEven
 * TPM_NONCE nonceOdd
 * BOOL continueAuthSession
 * TPM_AUTHDATA ownerAuth
 *
 * TPM_TAG tag
 * UINT32 paramSize
 * TPM_RESULT returnCode
 * TPM_COMMAND_CODE ordinal
 * TPM_KEY idKey
 * UINT32 identityBindingSize
 * BYTE[] identityBinding
 * TPM_NONCE srkNonceEven
 * TPM_NONCE srknonceOdd
 * BOOL continueSrkSession
 * TPM_AUTHDATA srkAuth
 * TPM_NONCE nonceEven
 * TPM_NONCE nonceOdd
 * BOOL continueAuthSession
 * TPM_AUTHDATA resAuth
 *
 * This translates to the following Scala method stub:
 *
 * package
 *
 * import tpm.structures.custom.TpmData
 * import tpm.structures.custom.AuthInfo
 * import tpm.strcutures. ...
 * import tpm.structures. ...
 * import tpm.structures. ...
 *
 * class Identity {
 *
 * /..
 *  . @note TpmData and AuthInfo parameters (if any) are read-write. All other parameters are read-only
 *  .
 *  . @param tpmData Internal data held by the TPM
 *  . @param srkAuth The authorization session handle used for SRK authorization.
 *  . @param ownerAuth The authorization session handle used for owner authentication. Session type MUST be OSAP.
 *  . @param identityAuth Encrypted usage AuthData for the new identity
 *  . @param labelPrivCADigest The digest of the identity label and privacy CA chosen for the AIK
 *  . @param idKeyParams Structure containing all parameters of new identity key. pubKey.keyLength and idKeyParams.encData are both 0 MAY be TPM_KEY12
 *  .
 *  . @return idKey (TpmKey) The newly created identity key. MAY be TPM_KEY12
 *  . @return identityBinding (Array[Byte]) Signature of TPM_IDENTITY_CONTENTS using idKey.private.
 *  ./
 * def TpmMakeIdentity(
 *     tpmData: TpmData,
 *     srkAuth: AuthInfo,
 *     ownerAuth: AuthInfo,
 *     identityAuth: TpmEncauth,
 *     labelPrivCADigest: TpmChosenidHash,
 *     idKeyParams: TpmKey): (TpmKey, Array[Byte]) = {
 *
 *     (null, null)
 * }
 */
object ScalaCommands {

    // ======================================================
    // Define classes (based on commands)
    // ======================================================

    val commandGroups = Vector(
        "Undef",
        "Scope",
        "Description",
        "Startup",
        "Testing",
        "OptIn",
        "Ownership",
        "Capability",
        "Auditing",
        "Management",
        "Storage",
        "Migration",
        "Maintenance",
        "Cryptographic",
        "EKHandling",
        "Identity",
        "Integrity",
        "ChangingAuth",
        "AuthSessions",
        "Delegation",
        "NVStorage",
        "SessionManagement",
        "Eviction",
        "Ticks",
        "Transport",
        "Counter",
        "DAA",
        "Depricated",
        "Deleted")

    // ======================================================
    // Define directories (based on structures)
    // ======================================================

    val packages = Vector(
        "custom",
        "scope",
        "helper",
        "structtags",
        "types",
        "basic",
        "tpmtags",
        "internal",
        "pcr",
        "storage",
        "tpmkey",
        "signed",
        "identity",
        "transport",
        "audit",
        "tick",
        "return",
        "ordinals",
        "context",
        "nvstorage",
        "delegate",
        "capability",
        "daa",
        "redirection",
        "deprecated")

    // ==========================================================
    // Constants and simple definitions
    // ==========================================================

    val FixedByteArray = """BYTE\[(\d+)\]""".r

    val tab = "    "

    def tab(n: Int): String = tab * n

    // ==========================================================
    // Input File and output directory
    // ==========================================================

    val structuresInputFile = "resources/tpm-structures.xml" // input file
    val commandsInputFile = "resources/tpm-commands.xml" // input file
    val commandsDir = "resources/scala/tpm/commands/" // output directory

    // ==========================================================
    // Main method
    // ==========================================================    

    def main(args: Array[String]) {

        // ======================================================
        // Read commands and structures from XML and create List[TpmCommand] and List[TpmStructure]
        // ======================================================

        val tpmCommandsXml = xml.XML.loadFile(commandsInputFile)
        val commands: List[TpmCommand] = (tpmCommandsXml \ "command").map(TpmCommand.fromXML(_)).toList
        val tpmStructuresXml = xml.XML.loadFile(structuresInputFile)
        val structures: List[TpmStructure] = (tpmStructuresXml \ "structure").map(TpmStructure.fromXML(_)).toList
        val sMap: Map[String, TpmStructure] = structures.map(s => (s.name, s)).toMap

        // ======================================================
        // Remove auth blocks, init params, size params; add tpm data and auth info
        // ======================================================        

        def revisedCommand(c: TpmCommand): TpmCommand = {
            val tagRqu = c.inParams.head.description
            val in1 = c.inParams.drop(3)
            val out1 = c.outParams.drop(4)
            val (in2, out2) = tagRqu match {
                case "TPM_TAG_RQU_AUTH1_COMMAND" => {
                    val (coreParams, authBlock) = in1.splitAt(in1.length - 5)
                    val authParam = authBlock.head.copy(name = authBlock.last.name, typeName = "AUTH_INFO")
                    (authParam :: coreParams, out1.dropRight(4))
                }
                case "TPM_TAG_RQU_AUTH2_COMMAND" => {
                    val (coreParams, authBlocks) = in1.splitAt(in1.length - 10)
                    val (authBlock1, authBlock2) = authBlocks.splitAt(5)
                    val authParam1 = authBlock1.head.copy(name = authBlock1.last.name, typeName = "AUTH_INFO")
                    val authParam2 = authBlock2.head.copy(name = authBlock2.last.name, typeName = "AUTH_INFO")
                    (authParam1 :: authParam2 :: coreParams, out1.dropRight(8))
                }
                case _ => (in1, out1)
            }
            val in3 = in2.filter { p => !(p.name.endsWith("Size") && p.typeName.startsWith("UINT")) }
            val out3 = out2.filter { p => !(p.name.endsWith("Size") && p.typeName.startsWith("UINT")) }
            val tpmData = TpmParameter(name = "tpmData", typeName = "TPM_DATA", description = "Internal data held by the TPM")
            c.copy(inParams = tpmData :: in3, outParams = out3)
        }

        // ======================================================
        // Return set of structures to import based on revised TPM command
        // ======================================================        

        def imports(c: TpmCommand): Set[String] = {

            def keep(s: String): Boolean = {
                s match {
                    case "BOOL" | "BYTE" | "BYTE[]" => false
                    case FixedByteArray(n) => false
                    case x if x.startsWith("UINT") => false
                    case _ => true
                }
            }

            def change(s: String): String = if (s.endsWith("[]")) s.stripSuffix("[]") else s

            val inImp = c.inParams.filter(p => keep(p.typeName)).map(p => change(p.typeName)).toSet
            val outImp = c.outParams.filter(p => keep(p.typeName)).map(p => change(p.typeName)).toSet
            inImp.union(outImp)
        }

        // ======================================================
        // Create scala method from revised TPM command
        // ======================================================        

        def scalaMethod(c: TpmCommand): String = {

            def scalaType(s: String): String = {
                s match {
                    case "TPM_DATA" => "TpmData"
                    case "AUTH_INFO" => "AuthInfo"
                    case "BOOL" => "Boolean"
                    case "BYTE" => "Byte"
                    case FixedByteArray(n) => "Array[Byte]"
                    case x if x.startsWith("UINT") => "Int"
                    case x if x.endsWith("[]") => "Array[" + snakeToCamel(x.stripSuffix("[]")).capitalize + "]"
                    case x if x.startsWith("TPM") => snakeToCamel(x).capitalize
                    case x => throw new IllegalArgumentException(x + " is not a TPM type")
                }
            }

            def access(s: String) = if (s == "TPM_DATA" || s == "AUTH_INFO") "[read-write]" else "[read-only] "

            val sb = new StringBuffer
            sb.append(tab + "/**\n")
            sb.append(c.inParams.map(p => tab + " * @param " + p.name + " " + p.description + "\n").mkString)
            if (c.outParams.nonEmpty) sb.append(tab + " *\n")
            sb.append(c.outParams.map(p => tab + " * @return " + p.name + " " + p.description + "\n").mkString)
            sb.append(tab + " */\n")
            sb.append(tab + "def tpm" + c.name.stripPrefix("TPM_") + "(\n")
            sb.append(c.inParams.map(p => tab(2) + p.name + ": " + scalaType(p.typeName)).mkString("", ",\n", ")"))
            val returnTyp = {
                if (c.outParams.isEmpty) " = {\n"
                else if (c.outParams.tail.isEmpty) ": " + scalaType(c.outParams.head.typeName) + " = {\n"
                else c.outParams.map(p => scalaType(p.typeName)).mkString(": (", ", ", ") = {\n")
            }
            sb.append(returnTyp)
            sb.append("\n")
            val returnVal = {
                if (c.outParams.isEmpty) ""
                else if (c.outParams.tail.isEmpty) tab(2) + "null\n"
                else tab(2) + c.outParams.map(p => "null").mkString("(", ", ", ")\n")
            }
            sb.append(returnVal)
            sb.append(tab + "}\n")
            sb.toString
        }

        // ======================================================
        // Iterate through commands and create files
        // ======================================================        

        // create the commands directory if it does not already exist
        val cDir = new java.io.File(commandsDir);
        if (!cDir.exists) {
            if (cDir.mkdirs) println("Directory is created!") else println("Failed to create directory!")
        } else println("Directory already exists")

        val chapterGroups: Map[Int, List[TpmCommand]] = commands.groupBy(c => c.chapter)

        def importLine(s: String) = s match {
            case "TPM_DATA" => "import tpm.structures.custom.TpmData\n"
            case "AUTH_INFO" => "import tpm.structures.custom.AuthInfo\n"
            case _ => "import tpm.structures." + packages(sMap(s).chapter) + "." + snakeToCamel(s).capitalize + "\n"
        }

        for (i <- chapterGroups.keys.toList.sorted) {
            val methods = new ListBuffer[String]
            var classImports: Set[String] = Set.empty
            for (c <- chapterGroups(i)) {
                if (c.name != "TPM_Init") {
                    classImports = classImports.union(imports(revisedCommand(c)))
                    methods += scalaMethod(revisedCommand(c))
                }
            }

            if (methods.nonEmpty) {
                val sb = new StringBuffer
                sb.append("package tpm.commands\n\n")
                val lines = classImports.toList.sorted.map(s => importLine(s))
                val importLines = if (lines.isEmpty) "" else lines.distinct.sorted.mkString("")
                sb.append(importLines + "\n")
                sb.append("class " + commandGroups(i) + " {\n\n")
                sb.append(methods.toList.mkString("", "\n", "\n"))
                sb.append("}\n")
                val classSource = sb.toString
                //println("+++++++++++++++++++++++++++++++++++++++++++++++\n") //DEBUG
                //println(classSource) //DEBUG

                printClassToFile(commandsDir + commandGroups(i) + ".scala", classSource)
            }
        }

        //        for (c <- commands) {
        //            if (c.inParams.nonEmpty) {
        //                val source = scalaMethod(revisedCommand(c))
        //                //val filename = commandsDir + snakeToCamel(c.name).capitalize + ".scala"
        //                //printClassToFile(filename, source)
        //                println(source) //DEBUG
        //            }
        //        }

        def printClassToFile(filename: String, source: String) {
            val out = new java.io.FileWriter(filename)
            out.write(source)
            out.close
        }

    }

}