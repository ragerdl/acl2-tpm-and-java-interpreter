package tpmxml.test

import tpmxml.data._

object TypeTest {

    def main(args: Array[String]) {
        
        val structuresXml = xml.XML.loadFile("resources/tpm-structures-3.xml")
        val commandsXml = xml.XML.loadFile("resources/tpm-commands-2.xml")
        val structures: List[TpmStructure] = (structuresXml \ "structure").map(TpmStructure.fromXML(_)).toList
        val commands: List[TpmCommand] = (commandsXml \ "command").map(TpmCommand.fromXML(_)).toList
        
        // get relevant sets: structureNames, fieldTypes, and paramTypes
        val structureNames = structures.map(s => s.name).toSet
        val fields = structures.flatMap(s => s.fields)
        val fieldTypes = fields.map(f => f.typeName).toSet
        val inParams = commands.flatMap(c => c.inParams)
        val outParams = commands.flatMap(c => c.outParams)
        val inParamTypes = inParams.map(p => p.typeName).toSet
        val outParamTypes = outParams.map(p => p.typeName).toSet
        val paramTypes = inParamTypes | outParamTypes
        
        val f_not_s = fieldTypes &~ structureNames
        val p_not_s = paramTypes &~ structureNames
        
        println("Field types not named in TPM structures: " + f_not_s)
        println("Param types not named in TPM structures: " + p_not_s)
    }

}