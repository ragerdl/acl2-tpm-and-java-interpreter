package tpmxml.test

import tpmxml.data.TpmStructure
import tpmxml.data.TpmField
import tpmxml.data.TpmValue

object QuoteTest {
    
	def main(args: Array[String]) {
	    
		val tpmStructuresXml = xml.XML.loadFile("resources/tpm-structures-2.xml")
        val structures: List[TpmStructure] = (tpmStructuresXml \ "structure").map(TpmStructure.fromXML(_)).toList
        
        val (recordStructures, valueStructures) = structures.partition(_.fields.nonEmpty)
        
        for (r <- recordStructures; f <- r.fields) {
            if (f.description.contains("\"")) println(f.description.trim)
        }

        for (s <- valueStructures; v <- s.values) {
            if (v.description.contains("\"")) println(v.description.trim)
        }		
	}

}